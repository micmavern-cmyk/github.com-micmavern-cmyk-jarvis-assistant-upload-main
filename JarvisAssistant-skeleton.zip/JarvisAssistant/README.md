# Jarvis — Personal Voice Assistant Skeleton (Huawei P40 / Android)

This is a **compiling project skeleton**, not a finished app. Every module from the spec
exists with real Kotlin classes, correct wiring, and Gradle/Manifest setup — but several
pieces (messaging automation, the AI-provider JSON parsing, wake-word looping, reminder
scheduling) are marked `// TODO` with a short explanation of what's left, rather than faked.
The goal is that opening this in Android Studio gives you a real foundation to fill in,
not an illusion of a finished product.

## What's implemented vs. stubbed

| Area | Status |
|---|---|
| Project structure, Gradle, Manifest, permissions | Done |
| Dark UI (orb, main/settings/memory/history/debug/onboarding screens) | Done, functional Compose UI |
| Room database (memory + conversation history) | Done |
| Secure API key storage (EncryptedSharedPreferences) | Done |
| App launcher (open installed apps by name) | Done |
| Accessibility service (back/home/screenshot/scroll/click/type/read-text) | Done |
| Safety levels (SAFE / CONFIRM / HIGH_RISK) + confirmation flow | Done |
| Local rule-based intent parsing (open X, yes/no, "I'm bored", etc.) | Done |
| AI-provider intent parsing (full natural language) | **Stub** — needs your API's real request/response shape |
| Messaging automation (find contact, type, send) | **Stub** — needs per-app Accessibility node-finding logic |
| Reminders/alarms (WorkManager + AlarmClock intents) | **Stub** |
| Wake-word continuous listening loop | **Documented, not implemented** — see `voice/WakeWordListener.kt` for why, and the honest alternative (tap-to-talk + foreground-service listening) |

## Why no compiled APK is attached

I can't run the Android SDK, an emulator, or Gradle in this environment (no Android
toolchain, no network access here), so I can't actually invoke `./gradlew assembleDebug`
or verify the exact build here. Everything below is written to be correct against current
AndroidX/Compose/Kotlin versions, but the first build on your machine is where real
compile errors (if any) will surface — that's normal for a hand-written skeleton this size.

## 1. Open the project

1. Install Android Studio (Ladybug or newer) if you don't have it.
2. `File > Open`, select the `JarvisAssistant` folder.
3. Let Gradle sync. If it complains about the Kotlin/AGP/KSP versions in
   `build.gradle.kts`, bump them to whatever Android Studio's "Upgrade Assistant" suggests
   — they were pinned to versions current as of early 2026 but plugin releases move fast.

## 2. Add your AI API key

The key is never hard-coded. Two options while `SettingsScreen`'s save button is still a
TODO:
- Easiest for now: temporarily call `app.secureKeyStore.setAiApiKey("sk-...")` once (e.g.
  in `MainActivity.onCreate`) to seed it, then remove that line once the Settings UI is wired up.
- Proper fix: finish the `TODO` in `SettingsScreen.kt` to call
  `settingsRepository`/`secureKeyStore` on save.

`ai/providers/OpenAiProvider.kt` targets an OpenAI-compatible chat completions endpoint —
swap the URL/body/parsing if you're using a different provider.

## 3. Build the APK

### Option A — Android Studio on a PC
- Debug build (fastest, for your own testing): `Build > Make Project`, then
  `Build > Build Bundle(s)/APK(s) > Build APK(s)`, or from a terminal:
  ```
  ./gradlew assembleDebug
  ```
  The APK lands in `app/build/outputs/apk/debug/app-debug.apk`.

### Option B — Phone only, no PC (GitHub Actions cloud build)

A workflow is already included at `.github/workflows/build-apk.yml` — GitHub's own
servers will build the APK for you; you never need Android Studio or a computer.

1. **Create a free GitHub account** at github.com if you don't have one, and create a new
   **empty** repository (e.g. `jarvis-assistant`). Don't add a README/license when creating
   it — keep it empty so it doesn't conflict with these files.
2. **Get the code onto GitHub.** The most reliable phone-only way is via **Termux**
   (installable from F-Droid — not the Play Store, so it works fine on your GBox setup):
   - Install F-Droid (f-droid.org), then install **Termux** and **Termux:API** from it.
   - Open Termux and run:
     ```
     pkg update && pkg install git
     termux-setup-storage
     ```
     (grant the storage permission it asks for)
   - Extract this zip on your phone first (most file managers can "Extract" a .zip), then
     move the extracted `JarvisAssistant` folder into your phone's Downloads folder if it
     isn't already there.
   - Back in Termux:
     ```
     cd ~/storage/downloads/JarvisAssistant
     git init
     git add .
     git commit -m "Initial Jarvis skeleton"
     git branch -M main
     git remote add origin https://github.com/<your-username>/jarvis-assistant.git
     git push -u origin main
     ```
   - When it asks for a password, GitHub no longer accepts your account password for this —
     use a **Personal Access Token** instead: on github.com go to
     Settings > Developer settings > Personal access tokens > Generate new token
     (classic, "repo" scope is enough), copy it, and paste it as the password when Termux
     asks. Your username is your normal GitHub username.
3. **Watch it build.** On github.com, open your repo > **Actions** tab. A "Build Jarvis
   APK" run should start automatically within a few seconds of the push. It takes a few
   minutes.
4. **Download the APK.** Once the run finishes (green checkmark), open it, scroll to
   **Artifacts**, and download `jarvis-debug-apk` — that's a zip containing the real,
   installable `app-debug.apk`. Unzip it on your phone and tap the `.apk` file to install
   (make sure "Install unknown apps" is allowed for your file manager/browser).
5. **Re-run after changes.** Any time you edit code and `git push` again, a new build
   kicks off automatically — no need to touch Android Studio at all.


## 4. Install on the Huawei P40

Since there's no Play Store involved:
1. Enable **Settings > Additional settings > Developer options > USB debugging**, or just
   copy the APK to the phone and enable **Install from unknown sources** for your file
   manager.
2. `adb install app/build/outputs/apk/debug/app-debug.apk`, or tap the APK on-device.

## 5. Enable Accessibility Service

Settings > Accessibility > Installed services > **Jarvis Assistant** > turn on. Android
will show the exact description from `strings.xml` explaining what it's for — Jarvis never
tries to hide or auto-enable this.

## 6. Enable microphone permission

Granted via the normal Android runtime prompt the first time you tap the mic button, or
Settings > Apps > Jarvis > Permissions > Microphone.

## 7. Huawei battery/background settings

EMUI's own "App launch" manager can kill background listening even with standard Android
battery optimization disabled. Go to:
`Settings > Apps > Apps > Jarvis > App launch > switch to "Manage manually" > enable
Auto-launch, Secondary launch, and Run in background.`
(Also see `permissions/PermissionManager.kt`.)

## 8. First test

With the app open:
1. Tap the mic button (continuous "Hey Jarvis" listening isn't implemented yet — see the
   Wake-word section above — so tap-to-talk is the reliable path for now).
2. Say "Open Spotify" → should launch Spotify if installed.
3. Say "Go back" → Accessibility performs a global back action.
4. Say "Open WhatsApp" → should launch WhatsApp if installed.
5. Say "Message Mom that I'm coming home" → will currently respond with the
   "Messaging automation not yet implemented" failure message from
   `MessagingActionHandler` — this is the next piece worth building out, since it's the
   one genuinely complex per-app UI-automation task in the spec.

## Project layout

```
app/src/main/java/com/tawana/jarvis/
  ui/            Compose screens, theme, orb, nav host
  voice/         SpeechRecognizer, TTS, wake-word, VoiceController orchestrator
  ai/            AiProvider interface + OpenAI-compatible impl, IntentParser, intent model
  actions/       ActionEngine (planner + safety levels) and per-category handlers
  accessibility/ AccessibilityService + a facade (AccessibilityActionBridge)
  apps/          App name -> package resolution and launching
  memory/        Local memory repository (list/search/delete/export/import)
  database/      Room entities/DAOs/database
  settings/      DataStore-backed preferences
  permissions/   Permission checks + Huawei-specific onboarding text
  notifications/ Foreground service + its notification
  security/      Encrypted API key storage
  utils/         Constants, logging, Result wrapper
```

## Next build priorities, in order

1. **MessagingActionHandler** — the actual contact-search/type/send flow via Accessibility.
   This is the single highest-value piece to finish since most of the example commands in
   the spec route through it.
2. **OpenAiProvider.parseIntent** — real prompt + JSON parsing so free-form English
   ("tell my mom I'm coming home now") gets understood, not just the local regex rules.
3. **ReminderActionHandler** — AlarmClock intents for alarms/timers, WorkManager for
   reminders.
4. **WakeWordListener** — decide between foreground-service polling (cheap to build, costs
   battery, EMUI may kill it) vs. bundling an offline keyword-spotting library (real
   Alexa-like experience, more work).
