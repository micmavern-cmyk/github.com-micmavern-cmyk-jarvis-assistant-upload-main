# Add project specific ProGuard rules here.
# Jarvis is a single-user local app; rules kept minimal for the skeleton.
