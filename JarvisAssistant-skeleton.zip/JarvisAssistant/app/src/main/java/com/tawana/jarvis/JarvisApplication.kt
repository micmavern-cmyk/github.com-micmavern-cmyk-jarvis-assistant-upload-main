package com.tawana.jarvis

import android.app.Application
import com.tawana.jarvis.database.JarvisDatabase
import com.tawana.jarvis.memory.MemoryRepository
import com.tawana.jarvis.security.SecureKeyStore
import com.tawana.jarvis.settings.SettingsRepository

/**
 * Single-user, fully local application container.
 *
 * There is no DI framework wired in yet (Hilt would be a reasonable next step once the
 * skeleton is filled in) — for now this class is a simple manual service locator so every
 * module has one obvious place to get its dependencies from.
 */
class JarvisApplication : Application() {

    lateinit var database: JarvisDatabase
        private set

    lateinit var settingsRepository: SettingsRepository
        private set

    lateinit var secureKeyStore: SecureKeyStore
        private set

    lateinit var memoryRepository: MemoryRepository
        private set

    override fun onCreate() {
        super.onCreate()
        database = JarvisDatabase.getInstance(this)
        secureKeyStore = SecureKeyStore(this)
        settingsRepository = SettingsRepository(this)
        memoryRepository = MemoryRepository(database.memoryDao())
    }

    companion object {
        lateinit var instance: JarvisApplication
            private set
    }

    init {
        instance = this
    }
}
