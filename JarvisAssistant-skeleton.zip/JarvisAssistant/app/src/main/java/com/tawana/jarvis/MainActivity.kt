package com.tawana.jarvis

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.lifecycle.lifecycleScope
import com.tawana.jarvis.accessibility.AccessibilityActionBridge
import com.tawana.jarvis.actions.ActionEngine
import com.tawana.jarvis.actions.handlers.AppActionHandler
import com.tawana.jarvis.actions.handlers.MessagingActionHandler
import com.tawana.jarvis.actions.handlers.ReminderActionHandler
import com.tawana.jarvis.actions.handlers.SystemActionHandler
import com.tawana.jarvis.ai.IntentParser
import com.tawana.jarvis.ai.IntentParsingContext
import com.tawana.jarvis.ai.providers.OpenAiProvider
import com.tawana.jarvis.apps.AppLauncher
import com.tawana.jarvis.permissions.PermissionManager
import com.tawana.jarvis.ui.navigation.JarvisNavHost
import com.tawana.jarvis.ui.theme.JarvisTheme
import com.tawana.jarvis.voice.SpeechRecognizerManager
import com.tawana.jarvis.voice.TextToSpeechManager
import com.tawana.jarvis.voice.VoiceController
import kotlinx.coroutines.launch

/**
 * Composition root. Manual wiring (see JarvisApplication's note re: no DI framework yet)
 * so the whole VOICE -> AI -> ACTION -> ANDROID pipeline from the spec is assembled in one
 * readable place.
 */
class MainActivity : ComponentActivity() {

    private val microphonePermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { /* handled via PermissionManager checks on next compose pass */ }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val app = application as JarvisApplication
        val permissionManager = PermissionManager(this)
        val accessibilityBridge = AccessibilityActionBridge()
        val appLauncher = AppLauncher(this, app.settingsRepository)
        val aiProvider = OpenAiProvider(app.secureKeyStore)
        val intentParser = IntentParser(aiProvider)

        val actionEngine = ActionEngine(
            appActionHandler = AppActionHandler(appLauncher),
            messagingActionHandler = MessagingActionHandler(appLauncher, accessibilityBridge),
            systemActionHandler = SystemActionHandler(accessibilityBridge),
            reminderActionHandler = ReminderActionHandler(),
            autoSendEnabled = { false } // TODO: read app.settingsRepository.isAutoSendEnabled() synchronously via cached state
        )

        val ttsManager = TextToSpeechManager(this)
        val speechRecognizerManager = SpeechRecognizerManager(
            context = this,
            onResult = { text -> lifecycleScope.launch { /* voiceController.handleUtterance(text) once created below */ } },
            onError = { /* surfaced via DebugScreen's Logger sink */ }
        )

        val voiceController = VoiceController(
            speechRecognizerManager = speechRecognizerManager,
            textToSpeechManager = ttsManager,
            intentParser = intentParser,
            actionEngine = actionEngine,
            assistantName = { Constants_DEFAULT_ASSISTANT_NAME },
            contextProvider = {
                IntentParsingContext(
                    installedAppNames = emptyList(), // TODO: populate from PackageManager
                    knownContactNames = emptyList(),  // TODO: populate from app.memoryRepository
                    assistantName = Constants_DEFAULT_ASSISTANT_NAME
                )
            }
        )

        setContent {
            JarvisTheme {
                JarvisNavHost(
                    app = app,
                    voiceController = voiceController,
                    permissionManager = permissionManager
                )
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
    }
}

// Small local alias to keep the wiring block above readable; mirrors Constants.DEFAULT_ASSISTANT_NAME.
private val Constants_DEFAULT_ASSISTANT_NAME = com.tawana.jarvis.utils.Constants.DEFAULT_ASSISTANT_NAME
