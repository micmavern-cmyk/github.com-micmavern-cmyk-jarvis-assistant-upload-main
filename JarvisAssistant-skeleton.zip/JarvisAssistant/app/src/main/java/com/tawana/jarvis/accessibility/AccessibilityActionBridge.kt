package com.tawana.jarvis.accessibility

/**
 * Thin facade the actions/ package talks to, so handlers don't reach into the raw
 * AccessibilityService (and so isEnabled() has one obvious home).
 */
class AccessibilityActionBridge {
    fun isEnabled(): Boolean = JarvisAccessibilityService.instance != null

    fun goBack(): Boolean = JarvisAccessibilityService.instance?.performGlobalBack() ?: false
    fun goHome(): Boolean = JarvisAccessibilityService.instance?.performGlobalHome() ?: false
    fun takeScreenshot(): Boolean = JarvisAccessibilityService.instance?.performGlobalScreenshot() ?: false
    fun openNotificationPanel(): Boolean = JarvisAccessibilityService.instance?.openNotificationPanel() ?: false
    fun scroll(direction: String): Boolean = JarvisAccessibilityService.instance?.scroll(direction) ?: false
    fun clickByText(label: String): Boolean = JarvisAccessibilityService.instance?.clickByText(label) ?: false
    fun typeText(text: String): Boolean = JarvisAccessibilityService.instance?.typeIntoFocusedField(text) ?: false
    fun readVisibleText(): List<String> = JarvisAccessibilityService.instance?.readVisibleText() ?: emptyList()
}
