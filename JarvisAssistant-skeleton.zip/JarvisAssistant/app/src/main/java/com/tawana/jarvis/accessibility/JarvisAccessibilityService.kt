package com.tawana.jarvis.accessibility

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import com.tawana.jarvis.utils.Logger

/**
 * The user-authorized bridge onto the rest of the OS (spec section 4). Never starts itself,
 * never hides its presence — Android forces it to show up under Settings > Accessibility with
 * the label/description declared in accessibility_service_config.xml + strings.xml, and this
 * class only acts when AccessibilityActionBridge is called from a planned ActionEngine action,
 * i.e. always downstream of an explicit user command.
 */
class JarvisAccessibilityService : AccessibilityService() {

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        Logger.d(TAG, "Jarvis accessibility service connected.")
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Intentionally not logging window content by default — only read screen state
        // on demand when a planned action needs it (see readVisibleText()).
    }

    override fun onInterrupt() {
        Logger.d(TAG, "Jarvis accessibility service interrupted.")
    }

    override fun onDestroy() {
        super.onDestroy()
        if (instance === this) instance = null
    }

    fun performGlobalBack(): Boolean = performGlobalAction(GLOBAL_ACTION_BACK)
    fun performGlobalHome(): Boolean = performGlobalAction(GLOBAL_ACTION_HOME)
    fun performGlobalScreenshot(): Boolean = performGlobalAction(GLOBAL_ACTION_TAKE_SCREENSHOT)
    fun openNotificationPanel(): Boolean = performGlobalAction(GLOBAL_ACTION_NOTIFICATIONS)

    fun readVisibleText(): List<String> {
        val root: AccessibilityNodeInfo = rootInActiveWindow ?: return emptyList()
        val out = mutableListOf<String>()
        collectText(root, out)
        return out
    }

    private fun collectText(node: AccessibilityNodeInfo, out: MutableList<String>) {
        node.text?.toString()?.takeIf { it.isNotBlank() }?.let { out.add(it) }
        for (i in 0 until node.childCount) {
            node.getChild(i)?.let { collectText(it, out) }
        }
    }

    /** Tap the first node whose visible text matches [label] (case-insensitive substring). */
    fun clickByText(label: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val target = findNodeByText(root, label) ?: return false
        return target.performAction(AccessibilityNodeInfo.ACTION_CLICK)
    }

    private fun findNodeByText(node: AccessibilityNodeInfo, label: String): AccessibilityNodeInfo? {
        val text = node.text?.toString()
        if (text != null && text.contains(label, ignoreCase = true)) return node
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            findNodeByText(child, label)?.let { return it }
        }
        return null
    }

    fun typeIntoFocusedField(text: String): Boolean {
        val focused = rootInActiveWindow?.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: return false
        val args = android.os.Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
        }
        return focused.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
    }

    fun scroll(direction: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val action = if (direction == "up") {
            AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD
        } else {
            AccessibilityNodeInfo.ACTION_SCROLL_FORWARD
        }
        return root.performAction(action)
    }

    companion object {
        private const val TAG = "JarvisAccessibility"

        /** Set/cleared in onServiceConnected/onDestroy; null means the user hasn't enabled it. */
        var instance: JarvisAccessibilityService? = null
            private set
    }
}
