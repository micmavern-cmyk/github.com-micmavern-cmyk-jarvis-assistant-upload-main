package com.tawana.jarvis.actions

import com.tawana.jarvis.ai.model.JarvisIntent

/**
 * A planned, executable unit of work derived from a JarvisIntent. Splitting Intent (what
 * the user meant) from Action (what we're actually about to do) leaves room for the planner
 * to insert steps — e.g. SEND_MESSAGE becomes [open app -> find contact -> type text -> confirm -> send].
 */
data class PlannedAction(
    val id: String,
    val label: String,              // human-readable, used for the confirmation prompt / debug screen
    val safetyLevel: SafetyLevel,
    val sourceIntent: JarvisIntent,
    val payload: Map<String, String> = emptyMap()
)

sealed class ActionResult {
    data class Done(val message: String) : ActionResult()
    data class NeedsConfirmation(val action: PlannedAction, val prompt: String) : ActionResult()
    data class Refused(val reason: String) : ActionResult()
    data class Failed(val reason: String) : ActionResult()
}
