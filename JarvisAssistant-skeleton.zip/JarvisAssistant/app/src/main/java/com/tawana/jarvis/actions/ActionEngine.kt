package com.tawana.jarvis.actions

import com.tawana.jarvis.actions.handlers.AppActionHandler
import com.tawana.jarvis.actions.handlers.MessagingActionHandler
import com.tawana.jarvis.actions.handlers.ReminderActionHandler
import com.tawana.jarvis.actions.handlers.SystemActionHandler
import com.tawana.jarvis.ai.model.IntentType
import com.tawana.jarvis.ai.model.JarvisIntent
import java.util.UUID

/**
 * Action Planner + dispatcher (spec section 3: "AI INTENT UNDERSTANDING -> ACTION PLANNER
 * -> ACCESSIBILITY/ANDROID ACTION EXECUTOR"). This is the ONLY place that turns an intent
 * into something that actually touches the phone; everything runs through the whitelisted
 * IntentType enum, never arbitrary AI output.
 */
class ActionEngine(
    private val appActionHandler: AppActionHandler,
    private val messagingActionHandler: MessagingActionHandler,
    private val systemActionHandler: SystemActionHandler,
    private val reminderActionHandler: ReminderActionHandler,
    private val autoSendEnabled: () -> Boolean
) {

    /** Pending Level-2 action awaiting a CONFIRM/CANCEL utterance, if any. */
    private var pendingAction: PlannedAction? = null

    suspend fun handle(intent: JarvisIntent): ActionResult {
        if (intent.type == IntentType.CONFIRM) return resolvePending(confirmed = true)
        if (intent.type == IntentType.CANCEL) return resolvePending(confirmed = false)

        val planned = plan(intent)
        return dispatch(planned)
    }

    private fun plan(intent: JarvisIntent): PlannedAction {
        val safety = safetyLevelFor(intent.type)
        return PlannedAction(
            id = UUID.randomUUID().toString(),
            label = describe(intent),
            safetyLevel = safety,
            sourceIntent = intent,
            payload = intent.slots
        )
    }

    private suspend fun dispatch(action: PlannedAction): ActionResult {
        if (action.safetyLevel == SafetyLevel.HIGH_RISK) {
            return ActionResult.Refused(
                "That involves ${action.label.lowercase()}, which Jarvis will never automate. " +
                    "Please do that yourself in Android Settings."
            )
        }

        if (action.safetyLevel == SafetyLevel.CONFIRM && !autoSendEnabled()) {
            pendingAction = action
            return ActionResult.NeedsConfirmation(action, "Are you sure? ${action.label}?")
        }

        return execute(action)
    }

    private suspend fun resolvePending(confirmed: Boolean): ActionResult {
        val action = pendingAction ?: return ActionResult.Failed("Nothing to confirm.")
        pendingAction = null
        return if (confirmed) execute(action) else ActionResult.Refused("Cancelled.")
    }

    private suspend fun execute(action: PlannedAction): ActionResult {
        return when (action.sourceIntent.type) {
            com.tawana.jarvis.ai.model.IntentType.OPEN_APP,
            com.tawana.jarvis.ai.model.IntentType.CLOSE_APP,
            com.tawana.jarvis.ai.model.IntentType.OPEN_CAMERA,
            com.tawana.jarvis.ai.model.IntentType.OPEN_BROWSER,
            com.tawana.jarvis.ai.model.IntentType.OPEN_URL,
            com.tawana.jarvis.ai.model.IntentType.OPEN_SETTINGS -> appActionHandler.handle(action)

            com.tawana.jarvis.ai.model.IntentType.SEND_MESSAGE,
            com.tawana.jarvis.ai.model.IntentType.MAKE_CALL -> messagingActionHandler.handle(action)

            com.tawana.jarvis.ai.model.IntentType.SET_ALARM,
            com.tawana.jarvis.ai.model.IntentType.SET_TIMER,
            com.tawana.jarvis.ai.model.IntentType.CREATE_REMINDER -> reminderActionHandler.handle(action)

            else -> systemActionHandler.handle(action)
        }
    }

    /** Spec section 11's three-tier mapping. Kept centralized and explicit on purpose. */
    private fun safetyLevelFor(type: IntentType): SafetyLevel = when (type) {
        IntentType.OPEN_APP, IntentType.GO_HOME, IntentType.GO_BACK, IntentType.SCROLL,
        IntentType.SEARCH, IntentType.TAKE_SCREENSHOT, IntentType.OPEN_CAMERA,
        IntentType.OPEN_BROWSER, IntentType.READ_VISIBLE_TEXT, IntentType.PLAY_MEDIA,
        IntentType.PAUSE_MEDIA, IntentType.ADJUST_VOLUME, IntentType.OPEN_NOTIFICATION_PANEL,
        IntentType.COPY_TEXT, IntentType.SMALL_TALK, IntentType.RECALL_FACT,
        IntentType.REMEMBER_FACT, IntentType.ASK_AI, IntentType.SET_TIMER -> SafetyLevel.SAFE

        IntentType.SEND_MESSAGE, IntentType.MAKE_CALL, IntentType.CREATE_REMINDER,
        IntentType.SET_ALARM, IntentType.OPEN_SETTINGS, IntentType.CLOSE_APP,
        IntentType.OPEN_URL, IntentType.TYPE_TEXT, IntentType.CLICK -> SafetyLevel.CONFIRM

        IntentType.UNKNOWN, IntentType.CONFIRM, IntentType.CANCEL -> SafetyLevel.SAFE
    }

    private fun describe(intent: JarvisIntent): String = when (intent.type) {
        IntentType.OPEN_APP -> "Open ${intent.app ?: "that app"}"
        IntentType.SEND_MESSAGE -> "Send ${intent.contact ?: "that contact"}: \"${intent.message ?: ""}\""
        IntentType.MAKE_CALL -> "Call ${intent.contact ?: "that contact"}"
        else -> intent.rawUtterance
    }
}
