package com.tawana.jarvis.actions

/** Spec section 11. */
enum class SafetyLevel {
    SAFE,           // Level 1 — executes immediately
    CONFIRM,        // Level 2 — "Are you sure?" before executing
    HIGH_RISK       // Level 3 — never automated; refuse or hand off to the user
}
