package com.tawana.jarvis.actions.handlers

import com.tawana.jarvis.actions.ActionResult
import com.tawana.jarvis.actions.PlannedAction
import com.tawana.jarvis.apps.AppLauncher

class AppActionHandler(private val appLauncher: AppLauncher) {
    suspend fun handle(action: PlannedAction): ActionResult {
        val appName = action.sourceIntent.app ?: return ActionResult.Failed("No app name understood.")
        return when (val result = appLauncher.launch(appName)) {
            is com.tawana.jarvis.utils.JarvisResult.Success -> ActionResult.Done("Opening $appName.")
            is com.tawana.jarvis.utils.JarvisResult.Failure -> ActionResult.Failed(result.reason)
        }
    }
}
