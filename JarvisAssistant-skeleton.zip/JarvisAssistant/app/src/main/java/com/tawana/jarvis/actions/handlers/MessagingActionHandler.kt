package com.tawana.jarvis.actions.handlers

import com.tawana.jarvis.accessibility.AccessibilityActionBridge
import com.tawana.jarvis.actions.ActionResult
import com.tawana.jarvis.actions.PlannedAction
import com.tawana.jarvis.apps.AppLauncher

/**
 * Implements the SEND_MESSAGE flow from spec section 6:
 * open app -> find contact -> type message -> read back -> (confirmation is handled one
 * level up by ActionEngine, since it's a generic Level-2 concern) -> send.
 *
 * Real UI automation happens through AccessibilityActionBridge, since messaging apps
 * generally don't expose a "send to this exact contact" public Intent.
 */
class MessagingActionHandler(
    private val appLauncher: AppLauncher,
    private val accessibilityBridge: AccessibilityActionBridge
) {
    suspend fun handle(action: PlannedAction): ActionResult {
        val contact = action.sourceIntent.contact
        val message = action.sourceIntent.message

        if (contact == null || message == null) {
            return ActionResult.Failed("I didn't catch who to message or what to say.")
        }

        if (!accessibilityBridge.isEnabled()) {
            return ActionResult.Failed(
                "Accessibility permission is disabled, so I can't type into $contact's chat for you."
            )
        }

        // TODO: real flow — launch the user's default/mapped messaging app, use the
        // AccessibilityActionBridge to search for the contact, open the thread, and type
        // the message into the input field. Left as a stub for the skeleton.
        return ActionResult.Failed("Messaging automation not yet implemented in skeleton.")
    }
}
