package com.tawana.jarvis.actions.handlers

import com.tawana.jarvis.actions.ActionResult
import com.tawana.jarvis.actions.PlannedAction

/**
 * SET_ALARM / SET_TIMER / CREATE_REMINDER (spec section 10). Alarms/timers should prefer
 * standard Android Intents (AlarmClock.ACTION_SET_ALARM / ACTION_SET_TIMER) so they work
 * without any custom scheduling code; CREATE_REMINDER uses WorkManager + local Room storage
 * so it survives without Google/Firebase involvement.
 */
class ReminderActionHandler {
    suspend fun handle(action: PlannedAction): ActionResult {
        // TODO: dispatch AlarmClock intents for SET_ALARM/SET_TIMER, and schedule a
        // WorkManager one-off task + Room row for CREATE_REMINDER.
        return ActionResult.Failed("Reminder/alarm scheduling not yet implemented in skeleton.")
    }
}
