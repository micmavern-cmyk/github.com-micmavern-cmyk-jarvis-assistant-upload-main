package com.tawana.jarvis.actions.handlers

import com.tawana.jarvis.accessibility.AccessibilityActionBridge
import com.tawana.jarvis.actions.ActionResult
import com.tawana.jarvis.actions.PlannedAction
import com.tawana.jarvis.ai.model.IntentType

/**
 * Catch-all for the simpler Level-1/Level-2 phone actions from spec section 10 that don't
 * need their own handler: GO_HOME, GO_BACK, SCROLL, TAKE_SCREENSHOT, ADJUST_VOLUME, etc.
 */
class SystemActionHandler(private val accessibilityBridge: AccessibilityActionBridge) {
    suspend fun handle(action: PlannedAction): ActionResult {
        return when (action.sourceIntent.type) {
            IntentType.GO_HOME -> runOrFail(action) { accessibilityBridge.goHome() }
            IntentType.GO_BACK -> runOrFail(action) { accessibilityBridge.goBack() }
            IntentType.TAKE_SCREENSHOT -> runOrFail(action) { accessibilityBridge.takeScreenshot() }
            IntentType.SCROLL -> runOrFail(action) { accessibilityBridge.scroll(action.payload["direction"] ?: "down") }
            IntentType.SMALL_TALK -> ActionResult.Done(
                "Want music, YouTube, a game, or should I find something interesting?"
            )
            IntentType.ASK_AI -> ActionResult.Failed("ASK_AI routing not yet wired to ActionEngine in skeleton.")
            else -> ActionResult.Failed("I don't have that action wired up yet.")
        }
    }

    private suspend fun runOrFail(action: PlannedAction, block: suspend () -> Boolean): ActionResult {
        if (!accessibilityBridge.isEnabled()) {
            return ActionResult.Failed("Accessibility permission is disabled.")
        }
        return if (block()) ActionResult.Done(action.label) else ActionResult.Failed("Android blocked that operation.")
    }
}
