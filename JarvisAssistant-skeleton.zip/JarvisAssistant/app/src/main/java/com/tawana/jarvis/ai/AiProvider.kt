package com.tawana.jarvis.ai

import com.tawana.jarvis.utils.JarvisResult

/**
 * Abstraction over "whatever LLM answers ASK_AI / does intent parsing" so the backing
 * provider can be swapped (spec section 7) without touching the rest of the app.
 * No API key is ever hard-coded — implementations read it from SecureKeyStore.
 */
interface AiProvider {
    val name: String

    /** Free-form question -> free-form answer, used for "ask ChatGPT ..." (ASK_AI intent). */
    suspend fun ask(question: String): JarvisResult<String>

    /** Natural language utterance -> structured intent, used by IntentParser. */
    suspend fun parseIntent(utterance: String, context: IntentParsingContext): JarvisResult<String>
}

/**
 * Extra context that helps the model resolve ambiguous utterances, e.g. which apps are
 * actually installed, or what "Mom" resolves to from local memory/contacts.
 */
data class IntentParsingContext(
    val installedAppNames: List<String>,
    val knownContactNames: List<String>,
    val assistantName: String
)
