package com.tawana.jarvis.ai

import com.tawana.jarvis.ai.model.IntentType
import com.tawana.jarvis.ai.model.JarvisIntent
import com.tawana.jarvis.utils.JarvisResult

/**
 * Normalizes free-form English into a JarvisIntent (spec sections 3 and 16).
 *
 * Strategy: try a small set of fast local rules first (greetings, yes/no confirmation,
 * "open X") so the common cases work even without network/AI-provider access, per the
 * offline-mode requirement (section 12). Anything the local rules don't confidently
 * match gets escalated to the configured AiProvider for full natural-language understanding.
 */
class IntentParser(private val aiProvider: AiProvider) {

    suspend fun parse(utterance: String, context: IntentParsingContext): JarvisIntent {
        localRuleMatch(utterance)?.let { return it }

        return when (val result = aiProvider.parseIntent(utterance, context)) {
            is JarvisResult.Success -> decodeFromJson(result.value, utterance)
            is JarvisResult.Failure -> JarvisIntent(
                type = IntentType.UNKNOWN,
                rawUtterance = utterance,
                confidence = 0f
            )
        }
    }

    private fun localRuleMatch(utterance: String): JarvisIntent? {
        val text = utterance.trim().lowercase()

        val confirmWords = setOf("yes", "yep", "yeah", "send it", "do it", "confirm", "go ahead")
        val cancelWords = setOf("no", "nope", "cancel", "stop", "don't")
        if (text in confirmWords) return JarvisIntent(IntentType.CONFIRM, rawUtterance = utterance)
        if (text in cancelWords) return JarvisIntent(IntentType.CANCEL, rawUtterance = utterance)

        if (text.contains("i'm bored") || text.contains("im bored")) {
            return JarvisIntent(IntentType.SMALL_TALK, mapOf("topic" to "bored"), utterance)
        }

        val openMatch = Regex("^open (my )?(.+)$").find(text)
        if (openMatch != null) {
            val target = openMatch.groupValues[2].trim()
            return JarvisIntent(IntentType.OPEN_APP, mapOf("app" to target), utterance)
        }

        if (text == "take a screenshot" || text == "screenshot") {
            return JarvisIntent(IntentType.TAKE_SCREENSHOT, rawUtterance = utterance)
        }
        if (text == "go back") return JarvisIntent(IntentType.GO_BACK, rawUtterance = utterance)
        if (text == "go home" || text == "home screen") return JarvisIntent(IntentType.GO_HOME, rawUtterance = utterance)

        // Everything else — messaging, reminders, "ask ChatGPT", "remember that..." — needs
        // real language understanding and is handed to the AI provider.
        return null
    }

    private fun decodeFromJson(json: String, utterance: String): JarvisIntent {
        // TODO: real JSON decoding (kotlinx.serialization) once OpenAiProvider.parseIntent
        // returns the model's structured output. Kept as a stub so the pipeline compiles
        // and can be exercised end-to-end with fake data during development.
        return JarvisIntent(IntentType.UNKNOWN, rawUtterance = utterance, confidence = 0f)
    }
}
