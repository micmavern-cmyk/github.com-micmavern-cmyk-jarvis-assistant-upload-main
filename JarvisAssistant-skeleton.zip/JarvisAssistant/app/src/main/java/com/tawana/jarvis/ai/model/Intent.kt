package com.tawana.jarvis.ai.model

/**
 * The whitelisted set of things Jarvis is allowed to do (spec sections 3 and 10).
 * The AI layer's only job is to map free-form English onto one of these — it never
 * generates or executes arbitrary code.
 */
enum class IntentType {
    OPEN_APP,
    CLOSE_APP,
    GO_HOME,
    GO_BACK,
    SCROLL,
    CLICK,
    TYPE_TEXT,
    SEARCH,
    TAKE_SCREENSHOT,
    OPEN_SETTINGS,
    SET_ALARM,
    SET_TIMER,
    CREATE_REMINDER,
    OPEN_CAMERA,
    OPEN_BROWSER,
    OPEN_URL,
    MAKE_CALL,
    SEND_MESSAGE,
    READ_VISIBLE_TEXT,
    PLAY_MEDIA,
    PAUSE_MEDIA,
    ADJUST_VOLUME,
    OPEN_NOTIFICATION_PANEL,
    COPY_TEXT,
    ASK_AI,               // "ask ChatGPT ..."
    REMEMBER_FACT,        // "remember that ..."
    RECALL_FACT,          // "what did I tell you about ..."
    SMALL_TALK,           // "I'm bored", greetings, etc.
    CONFIRM,              // "yes" / "send it" / "do it"
    CANCEL,               // "no" / "cancel"
    UNKNOWN
}

/**
 * Structured output of the AI intent-understanding step. This is the contract between
 * ai/ and actions/ — the Action Planner only ever sees this, never raw text.
 */
data class JarvisIntent(
    val type: IntentType,
    val slots: Map<String, String> = emptyMap(),
    val rawUtterance: String,
    val confidence: Float = 1f
) {
    // Convenience accessors for the most common slots so call sites don't sprinkle
    // string literals everywhere.
    val app: String? get() = slots["app"]
    val contact: String? get() = slots["contact"]
    val message: String? get() = slots["message"]
    val query: String? get() = slots["query"]
    val url: String? get() = slots["url"]
    val time: String? get() = slots["time"]
}
