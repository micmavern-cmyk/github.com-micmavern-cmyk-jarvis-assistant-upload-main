package com.tawana.jarvis.ai.providers

import com.tawana.jarvis.ai.AiProvider
import com.tawana.jarvis.ai.IntentParsingContext
import com.tawana.jarvis.security.SecureKeyStore
import com.tawana.jarvis.utils.JarvisResult
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody

/**
 * Default AiProvider implementation. Talks directly to the configured AI API using the
 * key from SecureKeyStore — no Jarvis-run server sits in the middle. Swap this class (or
 * add a sibling) to point at a different provider; nothing outside ai/ needs to change.
 *
 * NOTE: this is a stub wiring — request/response parsing is intentionally minimal for the
 * skeleton and should be filled in against whichever provider's API is actually configured.
 */
class OpenAiProvider(
    private val secureKeyStore: SecureKeyStore,
    private val client: OkHttpClient = OkHttpClient()
) : AiProvider {

    override val name: String = "OpenAI-compatible"

    override suspend fun ask(question: String): JarvisResult<String> = withContext(Dispatchers.IO) {
        val apiKey = secureKeyStore.getAiApiKey()
            ?: return@withContext JarvisResult.Failure("No AI API key configured. Add one in Settings > AI Provider.")

        try {
            // TODO: build the real request body for the configured provider/model.
            val body = """{"model":"gpt-4o-mini","messages":[{"role":"user","content":${quote(question)}}]}"""
                .toRequestBody("application/json".toMediaType())

            val request = Request.Builder()
                .url("https://api.openai.com/v1/chat/completions")
                .addHeader("Authorization", "Bearer $apiKey")
                .post(body)
                .build()

            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) {
                    return@withContext JarvisResult.Failure("AI provider returned HTTP ${response.code}")
                }
                // TODO: parse the real JSON response shape instead of returning raw text.
                val raw = response.body?.string().orEmpty()
                JarvisResult.Success(raw)
            }
        } catch (t: Throwable) {
            JarvisResult.Failure("Could not reach AI provider.", t)
        }
    }

    override suspend fun parseIntent(utterance: String, context: IntentParsingContext): JarvisResult<String> =
        withContext(Dispatchers.IO) {
            // TODO: send a structured prompt (see ai/IntentParser.kt) and return raw JSON
            // for IntentParser to decode into a JarvisIntent.
            JarvisResult.Failure("parseIntent not yet implemented in skeleton.")
        }

    private fun quote(s: String) = "\"" + s.replace("\"", "\\\"") + "\""
}
