package com.tawana.jarvis.apps

import android.content.Context
import android.content.Intent
import android.provider.MediaStore
import com.tawana.jarvis.settings.SettingsRepository
import com.tawana.jarvis.utils.JarvisResult

/**
 * Opens installed apps by friendly name (spec section 5). Prefers the package manager's
 * launch intent; falls back to the mapping table for names that don't match an installed
 * app's label exactly (e.g. "camera" vs the actual Huawei camera package).
 */
class AppLauncher(
    private val context: Context,
    private val settingsRepository: SettingsRepository
) {
    suspend fun launch(spokenName: String): JarvisResult<Unit> {
        val normalized = spokenName.trim().lowercase()
        val pm = context.packageManager

        // 1. Try resolving by installed app label.
        val byLabel = pm.getInstalledApplications(0).firstOrNull { appInfo ->
            pm.getApplicationLabel(appInfo).toString().equals(normalized, ignoreCase = true)
        }

        val packageName = byLabel?.packageName
            ?: settingsRepository.getAppMappings().getOrDefault(normalized, AppRegistry.defaultMappings[normalized])

        if (packageName == null) {
            return JarvisResult.Failure("I couldn't find $spokenName on this phone.")
        }

        val launchIntent = pm.getLaunchIntentForPackage(packageName)
            ?: return JarvisResult.Failure("$spokenName doesn't expose a launch action.")

        return try {
            launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(launchIntent)
            JarvisResult.Success(Unit)
        } catch (t: Throwable) {
            JarvisResult.Failure("Android blocked opening $spokenName.", t)
        }
    }

    fun openCamera(): JarvisResult<Unit> = try {
        val intent = Intent(MediaStore.ACTION_IMAGE_CAPTURE).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(intent)
        JarvisResult.Success(Unit)
    } catch (t: Throwable) {
        JarvisResult.Failure("Couldn't open the camera.", t)
    }

    fun openUrl(url: String): JarvisResult<Unit> = try {
        val intent = Intent(Intent.ACTION_VIEW, android.net.Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(intent)
        JarvisResult.Success(Unit)
    } catch (t: Throwable) {
        JarvisResult.Failure("Couldn't open that link.", t)
    }
}
