package com.tawana.jarvis.apps

/**
 * Configurable app-name -> package-name mapping (spec section 5: "Do not hard-code only
 * one phone's package names."). Ships with sensible defaults but is editable from Settings
 * and persisted via SettingsRepository, so the user can point "Spotify" at whatever package
 * is actually installed on their P40 (including sideloaded/GBox variants).
 */
object AppRegistry {
    val defaultMappings: Map<String, String> = mapOf(
        "whatsapp" to "com.whatsapp",
        "spotify" to "com.spotify.music",
        "youtube" to "com.google.android.youtube",
        "chrome" to "com.android.chrome",
        "camera" to "com.huawei.camera",
        "settings" to "com.android.settings",
        "messages" to "com.android.mms",
        "gmail" to "com.google.android.gm"
    )
}
