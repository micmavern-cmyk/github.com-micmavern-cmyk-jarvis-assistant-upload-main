package com.tawana.jarvis.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.tawana.jarvis.database.dao.ConversationDao
import com.tawana.jarvis.database.dao.MemoryDao
import com.tawana.jarvis.database.entities.ConversationEntity
import com.tawana.jarvis.database.entities.MemoryEntity
import com.tawana.jarvis.utils.Constants

@Database(
    entities = [MemoryEntity::class, ConversationEntity::class],
    version = 1,
    exportSchema = false
)
abstract class JarvisDatabase : RoomDatabase() {
    abstract fun memoryDao(): MemoryDao
    abstract fun conversationDao(): ConversationDao

    companion object {
        @Volatile private var INSTANCE: JarvisDatabase? = null

        fun getInstance(context: Context): JarvisDatabase =
            INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    JarvisDatabase::class.java,
                    Constants.DATABASE_NAME
                ).build().also { INSTANCE = it }
            }
    }
}
