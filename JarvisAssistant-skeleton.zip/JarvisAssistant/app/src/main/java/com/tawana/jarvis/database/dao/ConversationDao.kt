package com.tawana.jarvis.database.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import com.tawana.jarvis.database.entities.ConversationEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface ConversationDao {
    @Query("SELECT * FROM conversation ORDER BY timestampMillis ASC")
    fun observeAll(): Flow<List<ConversationEntity>>

    @Insert
    suspend fun insert(entity: ConversationEntity)

    @Query("DELETE FROM conversation")
    suspend fun deleteAll()
}
