package com.tawana.jarvis.database.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query
import com.tawana.jarvis.database.entities.MemoryEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface MemoryDao {
    @Query("SELECT * FROM memory ORDER BY createdAtMillis DESC")
    fun observeAll(): Flow<List<MemoryEntity>>

    @Query("SELECT * FROM memory WHERE key LIKE '%' || :query || '%' OR value LIKE '%' || :query || '%'")
    suspend fun search(query: String): List<MemoryEntity>

    @Insert
    suspend fun insert(entity: MemoryEntity): Long

    @Delete
    suspend fun delete(entity: MemoryEntity)

    @Query("DELETE FROM memory")
    suspend fun deleteAll()
}
