package com.tawana.jarvis.database.entities

import androidx.room.Entity
import androidx.room.PrimaryKey

/** One turn of conversation history (spec section 15). */
@Entity(tableName = "conversation")
data class ConversationEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val speaker: String,     // "user" | "jarvis"
    val text: String,
    val timestampMillis: Long
)
