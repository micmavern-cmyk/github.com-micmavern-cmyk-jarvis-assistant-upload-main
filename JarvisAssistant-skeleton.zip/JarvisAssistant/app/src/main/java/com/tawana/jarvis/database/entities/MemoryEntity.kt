package com.tawana.jarvis.database.entities

import androidx.room.Entity
import androidx.room.PrimaryKey

/** One explicit fact the user told Jarvis to remember (spec section 8). */
@Entity(tableName = "memory")
data class MemoryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val key: String,          // e.g. "name", "mom_contact", "car_project_goal"
    val value: String,        // e.g. "Tawana", "Mom", "1700 horsepower"
    val rawStatement: String, // the original sentence, for context/search
    val createdAtMillis: Long
)
