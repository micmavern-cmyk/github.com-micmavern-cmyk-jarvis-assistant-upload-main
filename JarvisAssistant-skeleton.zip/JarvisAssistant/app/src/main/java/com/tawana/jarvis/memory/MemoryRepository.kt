package com.tawana.jarvis.memory

import com.tawana.jarvis.database.dao.MemoryDao
import com.tawana.jarvis.database.entities.MemoryEntity
import kotlinx.coroutines.flow.Flow

/**
 * Local-only memory store (spec section 8): list / search / delete-one / delete-all /
 * export / import, backed entirely by Room — nothing here ever leaves the device unless
 * the user explicitly exports it.
 */
class MemoryRepository(private val dao: MemoryDao) {

    fun observeAll(): Flow<List<MemoryEntity>> = dao.observeAll()

    suspend fun search(query: String): List<MemoryEntity> = dao.search(query)

    suspend fun remember(key: String, value: String, rawStatement: String) {
        dao.insert(
            MemoryEntity(
                key = key,
                value = value,
                rawStatement = rawStatement,
                createdAtMillis = System.currentTimeMillis()
            )
        )
    }

    suspend fun forget(entity: MemoryEntity) = dao.delete(entity)

    suspend fun forgetAll() = dao.deleteAll()

    /** Plain-text export the user can save/back up themselves — no cloud involved. */
    suspend fun exportAsText(all: List<MemoryEntity>): String =
        all.joinToString("\n") { "${it.key} = ${it.value}  (\"${it.rawStatement}\")" }

    /** TODO: parse the exportAsText format back into rows for import. */
    suspend fun importFromText(text: String) {
        text.lines().filter { it.isNotBlank() }.forEach { line ->
            val parts = line.split(" = ", limit = 2)
            if (parts.size == 2) {
                remember(key = parts[0].trim(), value = parts[1].trim(), rawStatement = line)
            }
        }
    }
}
