package com.tawana.jarvis.notifications

import android.app.Service
import android.content.Intent
import android.os.IBinder
import com.tawana.jarvis.utils.Constants

/**
 * Keeps wake-word listening alive while the app is backgrounded (spec section 2/13).
 * Only ever started explicitly by the user (a toggle in MainScreen/Settings) — never
 * auto-started on boot or hidden from the user, per section 4's "do not secretly control
 * the device" rule. Shows a persistent, visible notification the whole time it runs.
 *
 * NOTE: Android/Huawei background mic restrictions mean this is a best-effort approach,
 * not a guarantee — see PermissionManager.huaweiAppLaunchInstructions() and the onboarding
 * checklist for what the user needs to configure for it to survive Doze/App launch limits.
 */
class JarvisForegroundService : Service() {

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startForeground(
            Constants.FOREGROUND_SERVICE_NOTIFICATION_ID,
            NotificationHelper.buildForegroundNotification(this, "Listening for \"Jarvis\"...")
        )
        // TODO: start WakeWordListener here and route detections into VoiceController.
        return START_STICKY
    }

    override fun onDestroy() {
        super.onDestroy()
        // TODO: stop WakeWordListener cleanly.
    }
}
