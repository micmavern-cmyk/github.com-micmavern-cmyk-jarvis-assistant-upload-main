package com.tawana.jarvis.notifications

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build
import androidx.core.app.NotificationCompat
import com.tawana.jarvis.MainActivity
import com.tawana.jarvis.utils.Constants
import android.app.PendingIntent
import android.content.Intent

object NotificationHelper {

    fun ensureChannel(context: Context) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val manager = context.getSystemService(NotificationManager::class.java)
        val channel = NotificationChannel(
            Constants.FOREGROUND_SERVICE_CHANNEL_ID,
            "Jarvis listening",
            NotificationManager.IMPORTANCE_LOW
        ).apply {
            description = "Shows while Jarvis is listening for its wake phrase in the background."
        }
        manager.createNotificationChannel(channel)
    }

    fun buildForegroundNotification(context: Context, statusText: String): android.app.Notification {
        ensureChannel(context)
        val openAppIntent = PendingIntent.getActivity(
            context, 0,
            Intent(context, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(context, Constants.FOREGROUND_SERVICE_CHANNEL_ID)
            .setContentTitle("Jarvis")
            .setContentText(statusText)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentIntent(openAppIntent)
            .setOngoing(true)
            .build()
    }
}
