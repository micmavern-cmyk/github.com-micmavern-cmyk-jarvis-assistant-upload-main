package com.tawana.jarvis.permissions

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.provider.Settings
import androidx.core.content.ContextCompat
import com.tawana.jarvis.accessibility.JarvisAccessibilityService

/**
 * Central place to check/request everything from spec sections 4/13's onboarding checklist:
 * microphone, notifications, accessibility service, and Huawei-specific background/battery
 * exemptions. The UI layer (OnboardingScreen/PermissionsScreen) drives the user through
 * these one at a time — nothing here runs silently.
 */
class PermissionManager(private val context: Context) {

    fun hasMicrophonePermission(): Boolean =
        ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    fun isAccessibilityServiceEnabled(): Boolean = JarvisAccessibilityService.instance != null

    fun accessibilitySettingsIntent(): Intent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)

    fun batteryOptimizationSettingsIntent(): Intent = Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)

    fun appNotificationSettingsIntent(): Intent = Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).apply {
        putExtra(Settings.EXTRA_APP_PACKAGE, context.packageName)
    }

    /**
     * Huawei P40 / EMUI specifics (spec section 13): beyond standard Android battery
     * optimization, EMUI's own "App launch" manager can silently kill background services.
     * There is no public API to toggle this — onboarding must show the user exactly where
     * to go (Settings > Apps > Jarvis > App launch > Manage manually > enable all three
     * toggles) since Jarvis cannot set this for itself.
     */
    fun huaweiAppLaunchInstructions(): String =
        "On Huawei/EMUI: Settings > Apps > Apps > Jarvis > App launch > switch to " +
            "'Manage manually' and enable Auto-launch, Secondary launch, and Run in background. " +
            "Without this, EMUI may kill the wake-word listener after the screen turns off."
}
