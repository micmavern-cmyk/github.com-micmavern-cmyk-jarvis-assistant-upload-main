package com.tawana.jarvis.security

import android.content.Context
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

/**
 * Holds the user's own AI API key (spec section 7) using Android's Keystore-backed
 * EncryptedSharedPreferences. Never hard-coded, never sent anywhere except directly from
 * this device to the configured AI provider's API.
 */
class SecureKeyStore(context: Context) {

    private val masterKey = MasterKey.Builder(context)
        .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
        .build()

    private val prefs = EncryptedSharedPreferences.create(
        context,
        "jarvis_secure_prefs",
        masterKey,
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
    )

    fun getAiApiKey(): String? = prefs.getString(KEY_AI_API_KEY, null)

    fun setAiApiKey(key: String) {
        prefs.edit().putString(KEY_AI_API_KEY, key).apply()
    }

    fun clearAiApiKey() {
        prefs.edit().remove(KEY_AI_API_KEY).apply()
    }

    companion object {
        private const val KEY_AI_API_KEY = "ai_api_key"
    }
}
