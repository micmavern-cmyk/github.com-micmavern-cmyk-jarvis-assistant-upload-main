package com.tawana.jarvis.settings

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.tawana.jarvis.utils.Constants
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore(name = "jarvis_settings")

/**
 * Non-secret preferences (assistant name, wake phrase, voice speed, auto-send toggle,
 * app-name mappings). API keys live in SecureKeyStore instead — this repository never
 * touches those.
 */
class SettingsRepository(private val context: Context) {

    private object Keys {
        val ASSISTANT_NAME = stringPreferencesKey("assistant_name")
        val WAKE_PHRASE = stringPreferencesKey("wake_phrase")
        val VOICE_SPEED = stringPreferencesKey("voice_speed") // stored as string, parsed to Float
        val AUTO_SEND_ENABLED = booleanPreferencesKey("auto_send_enabled")
        val APP_MAPPINGS_JSON = stringPreferencesKey("app_mappings_json")
    }

    val assistantNameFlow = context.dataStore.data.map { it[Keys.ASSISTANT_NAME] ?: Constants.DEFAULT_ASSISTANT_NAME }
    val wakePhraseFlow = context.dataStore.data.map { it[Keys.WAKE_PHRASE] ?: Constants.DEFAULT_WAKE_PHRASE }
    val autoSendEnabledFlow = context.dataStore.data.map { it[Keys.AUTO_SEND_ENABLED] ?: false }

    suspend fun isAutoSendEnabled(): Boolean = autoSendEnabledFlow.first()

    suspend fun setAssistantName(name: String) {
        context.dataStore.edit { it[Keys.ASSISTANT_NAME] = name }
    }

    suspend fun setWakePhrase(phrase: String) {
        context.dataStore.edit { it[Keys.WAKE_PHRASE] = phrase }
    }

    suspend fun setAutoSendEnabled(enabled: Boolean) {
        context.dataStore.edit { it[Keys.AUTO_SEND_ENABLED] = enabled }
    }

    /** TODO: replace with real JSON (kotlinx.serialization) once the Settings UI needs to edit these. */
    fun getAppMappings(): Map<String, String> = emptyMap()
}
