package com.tawana.jarvis.ui.components

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.unit.dp
import com.tawana.jarvis.ui.theme.JarvisAccent
import com.tawana.jarvis.ui.theme.JarvisAccentDim
import com.tawana.jarvis.voice.VoiceState

/**
 * The central orb from spec section 14. Kept as a single lightweight Canvas draw (no
 * particle systems / heavy shaders) so it stays smooth on a Huawei P40's GPU.
 */
@Composable
fun JarvisOrb(state: VoiceState, modifier: Modifier = Modifier) {
    val transition = rememberInfiniteTransition(label = "orb-pulse")
    val pulse by transition.animateFloat(
        initialValue = 0.85f,
        targetValue = if (state == VoiceState.LISTENING || state == VoiceState.EXECUTING) 1.15f else 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 900, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "orb-pulse-value"
    )

    Canvas(modifier = modifier.size(180.dp)) {
        val radius = (size.minDimension / 2f) * pulse
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(JarvisAccent, JarvisAccentDim),
                center = center,
                radius = radius
            ),
            radius = radius,
            center = Offset(size.width / 2f, size.height / 2f)
        )
    }
}
