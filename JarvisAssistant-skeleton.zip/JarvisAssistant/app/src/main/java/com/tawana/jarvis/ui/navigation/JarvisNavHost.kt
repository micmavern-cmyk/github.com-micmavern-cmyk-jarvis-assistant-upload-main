package com.tawana.jarvis.ui.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.tawana.jarvis.JarvisApplication
import com.tawana.jarvis.permissions.PermissionManager
import com.tawana.jarvis.ui.screens.*
import com.tawana.jarvis.voice.VoiceController

object Routes {
    const val MAIN = "main"
    const val ONBOARDING = "onboarding"
    const val SETTINGS = "settings"
    const val MEMORY = "memory"
    const val HISTORY = "history"
    const val DEBUG = "debug"
}

@Composable
fun JarvisNavHost(
    app: JarvisApplication,
    voiceController: VoiceController,
    permissionManager: PermissionManager,
    navController: NavHostController = rememberNavController(),
    startDestination: String = Routes.MAIN
) {
    NavHost(navController = navController, startDestination = startDestination) {
        composable(Routes.MAIN) {
            MainScreen(voiceController = voiceController, onNavigate = { navController.navigate(it) })
        }
        composable(Routes.ONBOARDING) {
            OnboardingScreen(
                permissionManager = permissionManager,
                onRequestMicrophone = { /* wired from Activity via ActivityResultContracts */ },
                onOpenAccessibilitySettings = { /* start permissionManager.accessibilitySettingsIntent() */ },
                onOpenBatterySettings = { /* start permissionManager.batteryOptimizationSettingsIntent() */ },
                onDone = { navController.popBackStack() }
            )
        }
        composable(Routes.SETTINGS) {
            SettingsScreen(settingsRepository = app.settingsRepository, onOpenApiKeyEntry = { })
        }
        composable(Routes.MEMORY) {
            MemoryScreen(memoryRepository = app.memoryRepository)
        }
        composable(Routes.HISTORY) {
            HistoryScreen(conversationDao = app.database.conversationDao())
        }
        composable(Routes.DEBUG) {
            DebugScreen(permissionManager = permissionManager)
        }
    }
}
