package com.tawana.jarvis.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.tawana.jarvis.permissions.PermissionManager
import com.tawana.jarvis.utils.Logger

/**
 * Spec section 18: recognized speech, AI interpretation, generated intent, selected action,
 * result, errors, accessibility/mic/network status — all in one screen for debugging.
 */
@Composable
fun DebugScreen(permissionManager: PermissionManager) {
    val logLines = remember { mutableStateListOf<String>() }

    DisposableEffect(Unit) {
        val sink = object : Logger.DebugLogSink {
            override fun onLog(tag: String, message: String) {
                logLines.add(0, "[$tag] $message")
            }
        }
        Logger.sink = sink
        onDispose { Logger.sink = null }
    }

    Column(Modifier.fillMaxSize().padding(24.dp)) {
        Text("Debug", style = MaterialTheme.typography.headlineSmall)
        Spacer(Modifier.height(12.dp))

        Text("Accessibility enabled: ${permissionManager.isAccessibilityServiceEnabled()}")
        Text("Microphone permission: ${permissionManager.hasMicrophonePermission()}")

        Spacer(Modifier.height(12.dp))
        Text("Log", style = MaterialTheme.typography.titleMedium)
        LazyColumn {
            items(logLines) { line -> Text(line, style = MaterialTheme.typography.bodySmall) }
        }
    }
}
