package com.tawana.jarvis.ui.screens

import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.tawana.jarvis.database.dao.ConversationDao

/** Conversation history view + delete (spec section 15). */
@Composable
fun HistoryScreen(conversationDao: ConversationDao) {
    val history by conversationDao.observeAll().collectAsState(initial = emptyList())

    Column(Modifier.fillMaxSize().padding(24.dp)) {
        Text("Conversation History", style = MaterialTheme.typography.headlineSmall)
        Spacer(Modifier.height(12.dp))
        LazyColumn {
            items(history) { turn ->
                Text(
                    "${if (turn.speaker == "user") "You" else "Jarvis"}: ${turn.text}",
                    modifier = Modifier.padding(vertical = 4.dp)
                )
            }
        }
    }
}
