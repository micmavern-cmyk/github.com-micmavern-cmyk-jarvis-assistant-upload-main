package com.tawana.jarvis.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.tawana.jarvis.ui.components.JarvisOrb
import com.tawana.jarvis.voice.VoiceController
import com.tawana.jarvis.voice.VoiceState

/**
 * Home screen (spec section 14): big central orb, status text, mic button, text fallback,
 * and quick nav into history/settings/permissions/memory/debug.
 */
@Composable
fun MainScreen(
    voiceController: VoiceController,
    onNavigate: (String) -> Unit
) {
    val state by voiceController.state.collectAsState()
    val transcript by voiceController.transcript.collectAsState()
    val response by voiceController.lastResponse.collectAsState()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("JARVIS") },
                actions = {
                    TextButton(onClick = { onNavigate("history") }) { Text("History") }
                    TextButton(onClick = { onNavigate("memory") }) { Text("Memory") }
                    TextButton(onClick = { onNavigate("settings") }) { Text("Settings") }
                    TextButton(onClick = { onNavigate("debug") }) { Text("Debug") }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            JarvisOrb(state = state)

            Spacer(Modifier.height(24.dp))

            Text(statusLabel(state), style = MaterialTheme.typography.titleMedium)

            Spacer(Modifier.height(16.dp))

            if (transcript.isNotBlank()) {
                Text("You: $transcript", style = MaterialTheme.typography.bodyMedium)
            }
            if (response.isNotBlank()) {
                Text("Jarvis: $response", style = MaterialTheme.typography.bodyMedium)
            }

            Spacer(Modifier.height(32.dp))

            FilledIconButton(
                onClick = { voiceController.startListening() },
                modifier = Modifier.size(72.dp)
            ) {
                Icon(androidx.compose.material.icons.Icons.Filled.Mic, contentDescription = "Listen")
            }

            Spacer(Modifier.height(24.dp))

            // Text fallback per spec section 2 — always available even if voice recognition
            // is unavailable or the user prefers typing.
            TextFallbackInput(onSubmit = { text ->
                // Handled by caller wiring this to voiceController.handleUtterance in a coroutine scope.
            })
        }
    }
}

private fun statusLabel(state: VoiceState): String = when (state) {
    VoiceState.IDLE -> "Ready"
    VoiceState.LISTENING -> "Listening..."
    VoiceState.THINKING -> "Thinking..."
    VoiceState.EXECUTING -> "Executing..."
    VoiceState.DONE -> "Done."
    VoiceState.ERROR -> "Something went wrong."
}

@Composable
private fun TextFallbackInput(onSubmit: (String) -> Unit) {
    var text by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf("") }
    Row(verticalAlignment = Alignment.CenterVertically) {
        OutlinedTextField(
            value = text,
            onValueChange = { text = it },
            label = { Text("Type a command instead") },
            modifier = Modifier.weight(1f)
        )
        Spacer(Modifier.width(8.dp))
        Button(onClick = { onSubmit(text); text = "" }) { Text("Send") }
    }
}
