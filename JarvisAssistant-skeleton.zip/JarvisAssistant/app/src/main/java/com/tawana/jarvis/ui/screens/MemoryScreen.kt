package com.tawana.jarvis.ui.screens

import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.tawana.jarvis.database.entities.MemoryEntity
import com.tawana.jarvis.memory.MemoryRepository
import kotlinx.coroutines.launch

/** List / search / delete-one / delete-all view over local memory (spec section 8). */
@Composable
fun MemoryScreen(memoryRepository: MemoryRepository) {
    val memories by memoryRepository.observeAll().collectAsState(initial = emptyList())
    var query by remember { mutableStateOf("") }
    val scope = rememberCoroutineScope()

    Column(Modifier.fillMaxSize().padding(24.dp)) {
        Text("Memory", style = MaterialTheme.typography.headlineSmall)
        Spacer(Modifier.height(12.dp))

        OutlinedTextField(
            value = query,
            onValueChange = { query = it },
            label = { Text("Search memory") },
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(12.dp))

        val visible = if (query.isBlank()) memories else memories.filter {
            it.key.contains(query, true) || it.value.contains(query, true)
        }

        LazyColumn(modifier = Modifier.weight(1f)) {
            items(visible) { entity: MemoryEntity ->
                Card(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                    Row(
                        Modifier.padding(12.dp).fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text("${entity.key}: ${entity.value}", style = MaterialTheme.typography.bodyMedium)
                            Text(entity.rawStatement, style = MaterialTheme.typography.bodySmall)
                        }
                        TextButton(onClick = { scope.launch { memoryRepository.forget(entity) } }) {
                            Text("Delete")
                        }
                    }
                }
            }
        }

        Spacer(Modifier.height(12.dp))
        OutlinedButton(onClick = { scope.launch { memoryRepository.forgetAll() } }) {
            Text("Delete all memory")
        }
    }
}
