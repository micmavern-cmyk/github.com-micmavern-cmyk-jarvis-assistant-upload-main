package com.tawana.jarvis.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.tawana.jarvis.permissions.PermissionManager

/**
 * Spec sections 4 and 13: explain exactly why each permission is needed before asking,
 * and give the Huawei-specific checklist. Nothing here is hidden or auto-granted.
 */
@Composable
fun OnboardingScreen(
    permissionManager: PermissionManager,
    onRequestMicrophone: () -> Unit,
    onOpenAccessibilitySettings: () -> Unit,
    onOpenBatterySettings: () -> Unit,
    onDone: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(24.dp)
    ) {
        Text("Set up Jarvis", style = MaterialTheme.typography.headlineSmall)
        Spacer(Modifier.height(16.dp))

        PermissionStep(
            title = "Microphone",
            description = "Needed so Jarvis can hear your voice commands.",
            actionLabel = "Grant microphone access",
            onClick = onRequestMicrophone
        )

        PermissionStep(
            title = "Accessibility Service",
            description = "Lets Jarvis read the screen and tap/type/scroll on your behalf " +
                "— only when you ask it to, e.g. \"message Mom I'm coming home\". You'll " +
                "enable this in Android Settings; Jarvis never turns it on for you.",
            actionLabel = "Open Accessibility Settings",
            onClick = onOpenAccessibilitySettings
        )

        PermissionStep(
            title = "Background / battery settings (Huawei)",
            description = permissionManager.huaweiAppLaunchInstructions(),
            actionLabel = "Open Battery Settings",
            onClick = onOpenBatterySettings
        )

        Spacer(Modifier.height(24.dp))
        Button(onClick = onDone, modifier = Modifier.fillMaxWidth()) {
            Text("Done")
        }
    }
}

@Composable
private fun PermissionStep(title: String, description: String, actionLabel: String, onClick: () -> Unit) {
    Card(modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp)) {
        Column(Modifier.padding(16.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(4.dp))
            Text(description, style = MaterialTheme.typography.bodySmall)
            Spacer(Modifier.height(8.dp))
            OutlinedButton(onClick = onClick) { Text(actionLabel) }
        }
    }
}
