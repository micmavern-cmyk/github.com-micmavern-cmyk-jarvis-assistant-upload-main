package com.tawana.jarvis.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.tawana.jarvis.settings.SettingsRepository

/** Assistant name/personality, wake phrase, voice speed, auto-send, AI API key entry point. */
@Composable
fun SettingsScreen(
    settingsRepository: SettingsRepository,
    onOpenApiKeyEntry: () -> Unit
) {
    var assistantName by remember { mutableStateOf("") }
    var wakePhrase by remember { mutableStateOf("") }
    var autoSend by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        settingsRepository.assistantNameFlow.collect { assistantName = it }
    }

    Column(Modifier.fillMaxSize().padding(24.dp)) {
        Text("Settings", style = MaterialTheme.typography.headlineSmall)
        Spacer(Modifier.height(16.dp))

        OutlinedTextField(
            value = assistantName,
            onValueChange = { assistantName = it },
            label = { Text("Assistant name") },
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(12.dp))

        OutlinedTextField(
            value = wakePhrase,
            onValueChange = { wakePhrase = it },
            label = { Text("Wake phrase") },
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(12.dp))

        Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
            Switch(checked = autoSend, onCheckedChange = { autoSend = it })
            Spacer(Modifier.width(8.dp))
            Text("Auto-send messages without confirmation (Level 2 actions)")
        }

        Spacer(Modifier.height(24.dp))
        OutlinedButton(onClick = onOpenApiKeyEntry) { Text("Configure AI provider API key") }

        // TODO: wire save buttons to settingsRepository.setAssistantName/setWakePhrase/setAutoSendEnabled.
    }
}
