package com.tawana.jarvis.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

// Dark, futuristic-but-practical palette (spec section 14).
val JarvisBackground = Color(0xFF0B0E14)
val JarvisSurface = Color(0xFF141924)
val JarvisAccent = Color(0xFF3DE0FF)
val JarvisAccentDim = Color(0xFF1E6E7A)
val JarvisTextPrimary = Color(0xFFE7F6FF)
val JarvisTextSecondary = Color(0xFF7C8A9A)
val JarvisError = Color(0xFFFF5C6C)

private val JarvisColorScheme = darkColorScheme(
    background = JarvisBackground,
    surface = JarvisSurface,
    primary = JarvisAccent,
    secondary = JarvisAccentDim,
    onBackground = JarvisTextPrimary,
    onSurface = JarvisTextPrimary,
    error = JarvisError
)

@Composable
fun JarvisTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = JarvisColorScheme,
        content = content
    )
}
