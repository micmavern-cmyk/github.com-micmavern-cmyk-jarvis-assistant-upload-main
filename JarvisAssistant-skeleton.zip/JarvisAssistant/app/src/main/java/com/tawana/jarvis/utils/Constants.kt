package com.tawana.jarvis.utils

object Constants {
    const val DEFAULT_WAKE_PHRASE = "jarvis"
    const val DEFAULT_ASSISTANT_NAME = "Jarvis"

    // Personalized greeting lines used when the user addresses the assistant by name
    // or by their own name (e.g. "Hey Jarvis" / "Tawana"). Configurable in Settings;
    // these are just the shipped defaults.
    val DEFAULT_GREETINGS = listOf(
        "Hey boss, how are you?",
        "What's new, Mr. Tawana?",
        "Right here. What do you need?"
    )

    const val DATABASE_NAME = "jarvis.db"
    const val FOREGROUND_SERVICE_NOTIFICATION_ID = 1001
    const val FOREGROUND_SERVICE_CHANNEL_ID = "jarvis_listening_channel"

    const val ACTION_EXECUTE_FROM_NOTIFICATION = "com.tawana.jarvis.ACTION_EXECUTE_FROM_NOTIFICATION"
}
