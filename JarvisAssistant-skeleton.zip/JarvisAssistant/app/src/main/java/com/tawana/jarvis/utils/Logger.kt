package com.tawana.jarvis.utils

import android.util.Log

/**
 * Thin wrapper so debug-screen logging and logcat logging go through one place.
 * DebugLogSink is what backs the on-device Debug screen (section 18 of the spec).
 */
object Logger {

    interface DebugLogSink {
        fun onLog(tag: String, message: String)
    }

    var sink: DebugLogSink? = null

    fun d(tag: String, message: String) {
        Log.d(tag, message)
        sink?.onLog(tag, message)
    }

    fun e(tag: String, message: String, throwable: Throwable? = null) {
        Log.e(tag, message, throwable)
        sink?.onLog(tag, "ERROR: $message ${throwable?.message.orEmpty()}")
    }
}
