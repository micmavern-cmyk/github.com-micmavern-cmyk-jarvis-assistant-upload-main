package com.tawana.jarvis.utils

/**
 * Generic result wrapper used across voice/ai/actions so failures are always explicit —
 * per the spec's "never pretend an action succeeded" rule (section 17).
 */
sealed class JarvisResult<out T> {
    data class Success<T>(val value: T) : JarvisResult<T>()
    data class Failure(val reason: String, val cause: Throwable? = null) : JarvisResult<Nothing>()
}
