package com.tawana.jarvis.voice

import android.content.Context
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale

/**
 * Spoken responses (spec section 2), with configurable speed/voice. Uses the system TTS
 * engine — whatever the user has installed — so it works fully offline once a voice
 * pack is on the device.
 */
class TextToSpeechManager(context: Context, private val onReady: () -> Unit = {}) {

    private var tts: TextToSpeech? = null
    private var isReady = false
    var speechRate: Float = 1.0f
        set(value) {
            field = value
            tts?.setSpeechRate(value)
        }

    init {
        tts = TextToSpeech(context) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts?.language = Locale.getDefault()
                tts?.setSpeechRate(speechRate)
                isReady = true
                onReady()
            }
        }
    }

    fun speak(text: String, utteranceId: String = text.hashCode().toString()) {
        if (!isReady) return
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, utteranceId)
    }

    fun setOnDoneListener(onDone: (String) -> Unit) {
        tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {}
            override fun onDone(utteranceId: String?) { utteranceId?.let(onDone) }
            override fun onError(utteranceId: String?) {}
        })
    }

    fun shutdown() {
        tts?.stop()
        tts?.shutdown()
    }
}
