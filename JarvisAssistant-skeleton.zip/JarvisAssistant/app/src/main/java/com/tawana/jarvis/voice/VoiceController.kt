package com.tawana.jarvis.voice

import com.tawana.jarvis.actions.ActionEngine
import com.tawana.jarvis.actions.ActionResult
import com.tawana.jarvis.ai.AiProvider
import com.tawana.jarvis.ai.IntentParser
import com.tawana.jarvis.ai.IntentParsingContext
import com.tawana.jarvis.utils.Constants
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

enum class VoiceState { IDLE, LISTENING, THINKING, EXECUTING, DONE, ERROR }

/**
 * Orchestrates the full pipeline from the spec's final diagram:
 * VOICE INPUT -> AI INTENT -> ACTION PLANNER -> ANDROID ACTION -> RESULT -> VOICE RESPONSE.
 * This is what MainScreen and JarvisForegroundService both drive.
 */
class VoiceController(
    private val speechRecognizerManager: SpeechRecognizerManager,
    private val textToSpeechManager: TextToSpeechManager,
    private val intentParser: IntentParser,
    private val actionEngine: ActionEngine,
    private val assistantName: () -> String,
    private val contextProvider: () -> IntentParsingContext
) {
    private val _state = MutableStateFlow(VoiceState.IDLE)
    val state: StateFlow<VoiceState> = _state

    private val _transcript = MutableStateFlow("")
    val transcript: StateFlow<String> = _transcript

    private val _lastResponse = MutableStateFlow("")
    val lastResponse: StateFlow<String> = _lastResponse

    fun startListening() {
        _state.value = VoiceState.LISTENING
        speechRecognizerManager.startListening()
    }

    /** Called by SpeechRecognizerManager's onResult callback, or from the text-fallback input. */
    suspend fun handleUtterance(utterance: String) {
        _transcript.value = utterance
        _state.value = VoiceState.THINKING

        if (isAddressedByName(utterance)) {
            speak(Constants.DEFAULT_GREETINGS.random())
            _state.value = VoiceState.DONE
            return
        }

        val intent = intentParser.parse(utterance, contextProvider())

        _state.value = VoiceState.EXECUTING
        when (val result = actionEngine.handle(intent)) {
            is ActionResult.Done -> speak(result.message)
            is ActionResult.NeedsConfirmation -> speak(result.prompt)
            is ActionResult.Refused -> speak(result.reason)
            is ActionResult.Failed -> speak("I couldn't complete that. ${result.reason}")
        }
        _state.value = VoiceState.DONE
    }

    private fun isAddressedByName(utterance: String): Boolean {
        val text = utterance.trim().lowercase()
        val name = assistantName().lowercase()
        return text == name || text == "hey $name" || text == "tawana"
    }

    private fun speak(text: String) {
        _lastResponse.value = text
        textToSpeechManager.speak(text)
    }
}
