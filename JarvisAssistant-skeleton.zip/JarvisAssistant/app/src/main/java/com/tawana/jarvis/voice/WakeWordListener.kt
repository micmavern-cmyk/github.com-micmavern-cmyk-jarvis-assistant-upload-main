package com.tawana.jarvis.voice

/**
 * Spec section 2 is explicit: "Do not assume continuous microphone listening is always
 * possible... implement the most reliable Android-compatible solution... if permanent
 * wake-word listening is restricted, clearly explain the limitation."
 *
 * REALITY CHECK (documented here on purpose, not hidden in a code comment nobody reads):
 * Android has no public, GMS-free, always-on low-power wake-word API. Options, in order
 * of reliability on a Huawei P40 without Play Services:
 *
 *   1. Tap-to-talk (microphone button) — always works, zero battery cost. Default mode.
 *   2. Foreground-service continuous listening — works while the service is alive, but
 *      EMUI's battery/App-launch manager can and will kill it once the screen is off
 *      unless the user manually whitelists Jarvis (see PermissionManager.huaweiAppLaunchInstructions()).
 *      Also consumes noticeably more battery than tap-to-talk.
 *   3. On-device wake-word engine (e.g. an offline keyword-spotting library) bundled into
 *      the app — the most Alexa/Siri-like experience, but is a real ML component, not a
 *      stub; left as a documented future step rather than faked here.
 *
 * This class implements option 2 as the default "hands-free" mode, with option 1 always
 * available as a fallback the user can rely on regardless of battery/OEM restrictions.
 */
class WakeWordListener(
    private val speechRecognizerManager: SpeechRecognizerManager,
    private val wakePhrase: () -> String,
    private val onWakePhraseDetected: () -> Unit
) {
    private var isRunning = false

    fun start() {
        isRunning = true
        listenCycle()
    }

    fun stop() {
        isRunning = false
        speechRecognizerManager.stopListening()
    }

    private fun listenCycle() {
        if (!isRunning) return
        // TODO: real implementation re-arms SpeechRecognizerManager in a loop and checks
        // each result against wakePhrase(), or swaps in an offline keyword-spotter per the
        // class doc above. Left unimplemented in the skeleton to avoid faking a working
        // continuous-listen loop that would actually drain the battery if run as-is.
    }
}
